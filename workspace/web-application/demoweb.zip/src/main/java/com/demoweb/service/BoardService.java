package com.demoweb.service;

public class BoardService {

}
