package com.demoweb.dao;

public class BoardDao {

}
