
public class SeoulCoronaStatsDto {

}
