
public class SeoulCoronaStatsDao {

}
