import java.util.Scanner;

public class SeoulCoronaStatsApp {
	
	private Scanner scanner = new Scanner(System.in);
	
	public void doStart() {
		
		while (true) {
			String selection = selectMenu();
			System.out.println();
			
			if (selection.equals("0")) {
				System.out.println(">>>>> 프로그램이 종료됩니다. <<<<<");
				break;
			} else if (selection.equals("1")) {
				
			} else if (selection.equals("2")) {
			
			} else if (selection.equals("3")) {
				
			} else if (selection.equals("4")) {
				
			} else if (selection.equals("5")) {
				
			} else if (selection.equals("6")) {
				
			} else if (selection.equals("7")) {
				
			} else {
				System.out.println(">>>>> 지원하지 않는 작업입니다. <<<<<");
			}
			
			System.out.println();
		}
		
	}
	
	public String selectMenu() {
		System.out.println("************************************");
		System.out.println("* 1. 데이터 저장");
		System.out.println("* 2. 데이터 초기화");
		System.out.println("* 3. 일자별 확진자 발생 현황 조회");
		System.out.println("* 4. 자치구별 확진자 발생 현황 조회");
		System.out.println("* 5. 일자별, 자치구별 확진자 발생 현황 조회");
		System.out.println("* 6. 최대 확진자 발생일자와 자치구 조회");
		System.out.println("* 0. 종료");
		System.out.println("************************************");
		System.out.print("작업 번호 : ");
		String selection = scanner.nextLine();
		return selection;
		
	}
	

	public static void main(String[] args) {
		
		SeoulCoronaStatsApp app = new SeoulCoronaStatsApp();
		app.doStart();
	}

}
