package com.springexample.ioc;

public interface MessageService {

	String getMessage();
	
	
}