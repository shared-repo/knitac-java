package com.springexample.ioc;

public interface ServiceConsumer {

	void doSomething();

}