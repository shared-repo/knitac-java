
public interface MessageService {
	
	String makeMessage();

}
