
public interface ServiceConsumer {
		
	void doSomething();

}
