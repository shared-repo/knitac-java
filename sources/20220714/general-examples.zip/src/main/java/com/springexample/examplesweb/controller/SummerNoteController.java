package com.springexample.examplesweb.controller;

import java.io.File;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class SummerNoteController {

	@GetMapping(path = { "/summernote-example" })
	public String showCkeditorForm(String id, String content, Model model) {
		
		model.addAttribute("content", "이 데이터가 <b>웹 편집기</b>에 표시됩니다.");		
		return "examples/summernote-form";
	}
	
	@PostMapping(path = { "/summernote-example" }, produces = { "text/plain;charset=utf-8" })
	@ResponseBody
	public String processData(String id, String content) {
		
		
		return id + " / " + content;
	}
	
	@PostMapping(path = { "/summernote-upload" }, produces = { "application/json;charset=utf-8" })
	@ResponseBody
	public ArrayList<String> uploadImage(String id, String content, MultipartFile file, HttpServletRequest req) throws Exception {
		
		ArrayList<String> imagePaths = new ArrayList<String>();

		System.out.println(file.getOriginalFilename());
		String path = req.getServletContext().getRealPath("/resources/upload-files");
		file.transferTo(new File(path, file.getOriginalFilename()));
		imagePaths.add("/examples-web/resources/upload-files/" + file.getOriginalFilename());
		
		return imagePaths;

		
	}
	
}
