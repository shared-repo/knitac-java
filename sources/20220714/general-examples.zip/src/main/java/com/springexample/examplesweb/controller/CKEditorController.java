package com.springexample.examplesweb.controller;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class CKEditorController {

	@GetMapping(path = { "/ckeditor-example" })
	public String showCkeditorForm(String id, String content, Model model) {
		
		model.addAttribute("content", "이 데이터가 <b>웹 편집기</b>에 표시됩니다.");
		
		return "examples/ckeditor-form";
	}
	
	@PostMapping(path = { "/ckeditor-example" }, produces = { "text/plain;charset=utf-8" })
	@ResponseBody
	public String processData(String id, String content) {
		
		
		return id + " / " + content;
	}
	
	@PostMapping(path = { "/ckeditor-upload" })
	@ResponseBody
	public String uploadImage(MultipartFile upload, HttpServletRequest req) throws Exception {
		
		System.out.println(upload.getOriginalFilename());
		String path = req.getServletContext().getRealPath("/resources/upload-files");
		upload.transferTo(new File(path, upload.getOriginalFilename()));
		
		return "{\"filename=\" : \"" + upload.getOriginalFilename() + "\", \"uploaded\" : 1, \"url\" : \"" + "/examples-web/resources/upload-files/" + upload.getOriginalFilename() + "\" }";
		
	}
	
}
